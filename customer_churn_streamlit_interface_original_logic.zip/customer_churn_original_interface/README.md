# Customer Churn Analysis and Prediction System — Streamlit Interface

This package adds a separate Streamlit web interface around the logic in the supplied Python program. It does not overwrite or modify the user's original terminal program.

## Files
- `app.py`: Streamlit interface, using the same data preparation, plots, Logistic Regression setup, target rule, train/test split, accuracy calculation, and prediction probability output as the supplied code.
- `bank_customer_data-1.csv`: the CSV supplied by the user, copied into the app folder under the filename expected by the app.
- `requirements.txt`: dependencies for Streamlit Cloud.

## Run locally
```bash
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

## Deploy
1. Upload `app.py`, `requirements.txt`, and `bank_customer_data-1.csv` to the root of a GitHub repository.
2. Commit the files. The default branch is usually `main` after the first commit.
3. In Streamlit Community Cloud, select that repository, branch `main` (or the branch shown in GitHub), and main file path `app.py`.
4. Click Deploy.

## Preserved model behavior
The app preserves the provided code's target rule `Churn = (Rating <= 5).astype(int)` and trains Logistic Regression on `Rating` alone. Customer ID and Balance are collected and displayed but are not model inputs, matching the supplied program. As the target is derived directly from Rating, the result is a demonstration of the original rule rather than a validated real-world churn model.
